import React from 'react'

interface Props {
  query: string
  onQueryChange: (q: string) => void
  onAlerts: () => void
  extendedMode: boolean
  onToggleExtended: () => void
}

export function Header({ query, onQueryChange, onAlerts, extendedMode, onToggleExtended }: Props) {
  return (
    <header className="header">
      <div className="header-left">
        <div className="logo">
          <div className="logo-mark">MI</div>
          <div>
            <div className="logo-text">MARKET INTELLIGENCE</div>
            <div className="logo-sub">AI • Macro & Fundamental • v3.0</div>
          </div>
        </div>
      </div>

      <div className="header-center">
        <div className="search-wrap">
          <span className="search-icon">⌕</span>
          <input
            className="search-input"
            placeholder="Search asset, event, source..."
            value={query}
            onChange={e => onQueryChange(e.target.value)}
          />
        </div>
      </div>

      <div className="header-right">
        <button className={`pill ${extendedMode ? 'active' : ''}`} onClick={onToggleExtended} style={{ cursor: 'pointer' }}>
          {extendedMode ? 'EXTENDED ON' : 'EXTENDED OFF'}
        </button>
        <button className="pill green">ENGINE ACTIVE</button>
        <button className="icon-btn" onClick={onAlerts} title="Alerts">
          🔔
        </button>
        <div className="icon-btn" style={{ background: 'var(--text)', color: 'var(--bg)', fontWeight: 700, fontSize: 11 }}>AK</div>
      </div>
    </header>
  )
}
