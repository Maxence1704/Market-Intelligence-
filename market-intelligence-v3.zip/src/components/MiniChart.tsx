import React from 'react'

interface Props {
  data: number[]
  color?: string
  height?: number
}

export function MiniChart({ data, color = 'var(--text-2)', height = 48 }: Props) {
  if (data.length < 2) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const width = 120
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width
    const y = height - ((v - min) / range) * (height - 8) - 4
    return `${x},${y}`
  }).join(' ')

  return (
    <div className="mini-chart" style={{ height, width: '100%' }}>
      <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: 'block' }}>
        <polyline points={points} fill="none" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />
        <polyline points={`${points} ${width},${height} 0,${height}`} fill={color} fillOpacity={0.08} stroke="none" />
      </svg>
    </div>
  )
}

export function Sparkline({ trend = 'up' }: { trend?: 'up' | 'down' | 'flat' }) {
  const dataUp = [10, 12, 11, 14, 13, 16, 18, 17, 20, 22]
  const dataDown = [22, 20, 19, 17, 18, 15, 13, 14, 11, 10]
  const dataFlat = [12, 13, 12.5, 13, 12.8, 13.2, 13, 12.9, 13.1, 13]
  const map = { up: dataUp, down: dataDown, flat: dataFlat }
  const colorMap = { up: 'var(--green)', down: 'var(--red)', flat: 'var(--text-3)' }
  return <MiniChart data={map[trend]} color={colorMap[trend]} height={36} />
}
