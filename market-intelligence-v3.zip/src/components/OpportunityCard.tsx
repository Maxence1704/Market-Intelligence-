import React, { useState } from 'react'
import { Opportunity } from '../types'
import { ProbabilityRing } from './ProbabilityRing'
import { Badge, VerifiedBadge, DemoBadge, ImpactBadge } from './Badge'
import { Sparkline } from './MiniChart'

interface Props {
  opp: Opportunity
  onAnalyze: (id: string) => void
  onWatch: (id: string) => void
  isWatched?: boolean
}

export function OpportunityCard({ opp, onAnalyze, onWatch, isWatched }: Props) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className={`opp-card ${expanded ? 'active' : ''} ${opp.isExtended ? 'extended' : ''} fade-in`} onClick={() => setExpanded(!expanded)}>
      {/* Top */}
      <div className="opp-top">
        <div>
          <div className="opp-asset">{opp.market}</div>
          <div className="opp-ticker">{opp.ticker} • {opp.id} • {opp.isDemo && <DemoBadge />} {opp.isExtended && <Badge variant="default">EXTENDED</Badge>}</div>
        </div>
        <div className={`opp-dir ${opp.direction.toLowerCase()}`}>
          {opp.direction} {opp.arrow}
        </div>
      </div>

      {/* Mid - Probability + Stats */}
      <div className="opp-mid">
        <ProbabilityRing value={opp.probability} direction={opp.direction} label="Prob" />
        <div className="opp-stats">
          <div className="stat-row">
            <div className="stat-label">Impact</div>
            <ImpactBadge impact={opp.impact} />
            <span className="stat-value" style={{ marginLeft: 6, fontSize: 10 }}>{opp.timeHorizon}</span>
          </div>
          <div className="stat-row">
            <div className="stat-label">Move</div>
            <div className="stat-value" style={{ color: opp.direction === 'LONG' ? 'var(--green)' : 'var(--red)' }}>{opp.expectedMove}</div>
          </div>
          <div className="stat-row">
            <div className="stat-label">Sources</div>
            <VerifiedBadge count={opp.sources.filter(s => s.verified).length} />
          </div>
          <div style={{ marginTop: 4 }}>
            <Sparkline trend={opp.direction === 'LONG' ? 'up' : 'down'} />
          </div>
        </div>
      </div>

      {/* Catalyst */}
      <div className="opp-catalyst" onClick={e => e.stopPropagation()}>
        <div className="catalyst-dot">⚡</div>
        <div className="catalyst-main">
          <div className="catalyst-name">{opp.catalyst.event}</div>
          <div className="catalyst-date">{opp.catalyst.date} • {opp.catalyst.time} • {opp.catalyst.countdown}</div>
        </div>
        <div className="impact-pill">{opp.catalyst.importance}</div>
      </div>

      {/* Chain visual */}
      <div className="opp-chain">
        {opp.chain.slice(0, 4).map((step, i) => (
          <React.Fragment key={step.id}>
            <div className={`chain-node ${i === opp.chain.length - 1 ? 'active' : ''}`}>{step.title}</div>
            {i < 3 && <span className="chain-arrow">→</span>}
          </React.Fragment>
        ))}
        {opp.chain.length > 4 && <span className="chain-node">+{opp.chain.length - 4}</span>}
      </div>

      {/* Thesis - one liner */}
      <div className="opp-thesis">
        <strong>{opp.thesisOneLiner}</strong> — {opp.summary}
      </div>

      {/* Expanded - Why */}
      {expanded && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, animation: 'fadeIn .3s ease' }}>
          <div style={{ height: 1, background: 'var(--border)', margin: '4px 0' }} />
          <div>
            <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', marginBottom: 8, fontWeight: 600 }}>Why this trade? — 3 key reasons</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {opp.whyDetailed.map((w, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, padding: '8px 10px', background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 10 }}>
                  <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-3)', minWidth: 20 }}>0{i + 1}</div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text)' }}>{w.title}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.4 }}>{w.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ padding: '8px 10px', background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)', borderRadius: 10 }}>
            <div style={{ fontSize: 8, letterSpacing: '0.12em', color: 'var(--red)', textTransform: 'uppercase', fontWeight: 700, marginBottom: 4 }}>Invalidation</div>
            <div style={{ fontSize: 10, color: '#FFA0A0', lineHeight: 1.4 }}>{opp.invalidation.join(' • ')}</div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="opp-actions">
        <button
          className="btn btn-primary"
          onClick={e => {
            e.stopPropagation()
            onAnalyze(opp.id)
          }}
          style={{ flex: 1 }}
        >
          Analyze →
        </button>
        <button
          className="btn"
          onClick={e => {
            e.stopPropagation()
            onWatch(opp.id)
          }}
          style={{ width: 40, padding: 0 }}
          title={isWatched ? 'In watchlist' : 'Add to watchlist'}
        >
          {isWatched ? '✓' : '+'}
        </button>
      </div>
    </div>
  )
}
