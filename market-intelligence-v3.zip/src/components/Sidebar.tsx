import React from 'react'
import { Page } from '../types'

interface Props {
  current: Page
  onChange: (p: Page) => void
  highCount: number
  extendedCount: number
}

const nav: { id: Page; label: string; icon: string; count?: string }[] = [
  { id: 'overview', label: 'Overview', icon: '◧' },
  { id: 'markets', label: 'Markets', icon: '◫' },
  { id: 'calendar', label: 'Calendar', icon: '◨' },
  { id: 'watchlist', label: 'Watchlist', icon: '☆' },
  { id: 'history', label: 'History', icon: '◷' },
  { id: 'sources', label: 'Sources', icon: '🛡' }
]

export function Sidebar({ current, onChange, highCount, extendedCount }: Props) {
  return (
    <aside className="sidebar">
      <div className="nav-group">
        <div className="nav-label">Intelligence</div>
        {nav.map(item => (
          <div key={item.id} className={`nav-item ${current === item.id ? 'active' : ''}`} onClick={() => onChange(item.id)}>
            <span className="nav-icon">{item.icon}</span>
            {item.label}
            {item.id === 'overview' && <span className="nav-count">{highCount}</span>}
            {item.id === 'sources' && <span className="nav-count" style={{ color: '#93C5FD', borderColor: 'rgba(96,165,250,0.25)' }}>S → A+</span>}
          </div>
        ))}
      </div>

      <div className="nav-group">
        <div className="nav-label">Pipeline</div>
        <div style={{ padding: '8px 10px', background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 10, lineHeight: 1.6, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>
          COLLECT<br />↓ VERIFY<br />↓ CROSS-CHECK<br />↓ UNDERSTAND<br />↓ MODEL<br />↓ FILTER<br />↓ <span style={{ color: 'var(--text)' }}>MAX 10/WEEK</span>
        </div>
      </div>

      <div className="sidebar-bottom">
        <div className="status-row"><span>SCANNED</span><span>247 sources</span></div>
        <div className="status-bar"><div className="status-fill" style={{ width: '72%' }} /></div>
        <div className="status-row"><span>S TIER</span><span style={{ color: '#93C5FD' }}>68% primaires</span></div>
        <div className="status-row"><span>TRUST GATE</span><span style={{ color: 'var(--green)' }}>{highCount} PASSED</span></div>
        <div className="status-row"><span>EXTENDED</span><span>{extendedCount} in watch</span></div>
      </div>
    </aside>
  )
}

export function BottomNav({ current, onChange }: { current: Page; onChange: (p: Page) => void }) {
  return (
    <div className="bottom-nav">
      {nav.slice(0, 5).map(item => (
        <div key={item.id} className={`bottom-nav-item ${current === item.id ? 'active' : ''}`} onClick={() => onChange(item.id)}>
          <span className="icon">{item.icon}</span>
          {item.label}
        </div>
      ))}
    </div>
  )
}
