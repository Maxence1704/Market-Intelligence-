import React from 'react'

interface Props {
  value: number // 0-100
  size?: number
  direction?: 'LONG' | 'SHORT'
  label?: string
}

export function ProbabilityRing({ value, size = 64, direction = 'LONG', label = 'Probability' }: Props) {
  const strokeWidth = 5
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (value / 100) * circumference

  return (
    <div className={`prob-ring ${direction.toLowerCase()}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle className="prob-ring-bg" cx={size / 2} cy={size / 2} r={radius} strokeWidth={strokeWidth} />
        <circle
          className="prob-ring-fill"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="prob-ring-text">
        <div className="prob-ring-value">{value}%</div>
        <div className="prob-ring-label">{label}</div>
      </div>
    </div>
  )
}

export function MiniProbabilityBar({ value, direction }: { value: number; direction?: 'LONG' | 'SHORT' }) {
  const color = direction === 'SHORT' ? 'var(--red)' : direction === 'LONG' ? 'var(--green)' : 'var(--text)'
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1 }}>
      <div style={{ flex: 1, height: 3, background: 'var(--border)', borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: `${value}%`, height: '100%', background: color, borderRadius: 999, transition: 'width .6s' }} />
      </div>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-2)', minWidth: 32 }}>{value}%</span>
    </div>
  )
}
