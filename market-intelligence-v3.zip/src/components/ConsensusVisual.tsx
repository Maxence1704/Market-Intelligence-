import React from 'react'
import { Consensus } from '../types'
import { Badge } from './Badge'

interface Props {
  consensus: Consensus
}

export function ConsensusVisual({ consensus }: Props) {
  const items = [
    { label: 'Previous', value: consensus.previous, color: 'var(--text-3)', width: 65, badge: 'OFFICIAL' as const },
    { label: 'Consensus', value: consensus.consensus, color: 'var(--text-2)', width: 70, badge: 'TRADER' as const },
    { label: 'Market', value: consensus.pricing, color: 'var(--text-2)', width: 75, badge: 'MARKET' as const },
    { label: 'Model', value: consensus.model, color: 'var(--text)', width: 60, badge: 'MODEL' as const, highlight: true }
  ]

  return (
    <div className="consensus-visual">
      {items.map(it => (
        <div key={it.label} className="consensus-row">
          <div className="consensus-label">{it.label}</div>
          <div className="consensus-bar">
            <div className="consensus-fill" style={{ width: `${it.width}%`, background: it.color }} />
          </div>
          <div className="consensus-value" style={{ color: it.highlight ? 'var(--text)' : 'var(--text-2)', fontWeight: it.highlight ? 700 : 400 }}>
            {it.value}
          </div>
          <Badge variant={it.badge === 'OFFICIAL' ? 'official' : it.badge === 'TRADER' ? 'trader' : 'market'}>{it.badge}</Badge>
        </div>
      ))}
      <div style={{ marginTop: 8, padding: '6px 10px', background: 'rgba(234,179,8,0.08)', border: '1px solid rgba(234,179,8,0.18)', borderRadius: 8, fontSize: 10, color: '#EAB308', fontFamily: 'var(--mono)' }}>
        → {consensus.surprise}
      </div>
    </div>
  )
}

export function ScenarioDistribution({ scenarios }: { scenarios: { prob: number; label: string; desc: string }[] }) {
  const colors = ['var(--text)', 'var(--text-3)', 'var(--red)']
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div className="scenario-bar">
        {scenarios.map((s, i) => (
          <div key={i} className="scenario-seg" style={{ width: `${s.prob}%`, background: colors[i] || 'var(--text-3)' }} />
        ))}
      </div>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        {scenarios.map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, fontFamily: 'var(--mono)', color: 'var(--text-2)' }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: colors[i] }} />
            {s.prob}% {s.label}
          </div>
        ))}
      </div>
    </div>
  )
}
