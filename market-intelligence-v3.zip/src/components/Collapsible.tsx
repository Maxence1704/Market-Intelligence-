import React, { useState } from 'react'

interface Props {
  title: string
  icon?: string
  defaultOpen?: boolean
  children: React.ReactNode
  badge?: React.ReactNode
}

export function Collapsible({ title, icon, defaultOpen = false, children, badge }: Props) {
  const [open, setOpen] = useState(defaultOpen)

  return (
    <div className={`collapsible ${open ? 'open' : ''}`}>
      <div className="collapsible-head" onClick={() => setOpen(v => !v)}>
        <div className="collapsible-title">
          {icon && <span>{icon}</span>}
          {title}
          {badge && <span style={{ marginLeft: 6 }}>{badge}</span>}
        </div>
        <div className="collapsible-icon">›</div>
      </div>
      <div className="collapsible-body">{children}</div>
    </div>
  )
}
