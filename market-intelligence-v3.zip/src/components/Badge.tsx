import React from 'react'

type BadgeVariant = 'official' | 'trader' | 'market' | 'verified' | 'conflict' | 'demo' | 'default'

interface Props {
  variant?: BadgeVariant
  children: React.ReactNode
  size?: 'sm' | 'md'
}

export function Badge({ variant = 'default', children, size = 'sm' }: Props) {
  return (
    <span className={`badge ${variant}`} style={{ fontSize: size === 'sm' ? '8px' : '10px', padding: size === 'sm' ? '3px 7px' : '5px 10px' }}>
      {children}
    </span>
  )
}

export function VerifiedBadge({ count }: { count?: number }) {
  return <span className="badge verified">✓ {count ? `${count} VERIFIED` : 'VERIFIED'}</span>
}

export function DemoBadge() {
  return <span className="badge demo">DEMO DATA</span>
}

export function ImpactBadge({ impact }: { impact: string }) {
  const colorMap: Record<string, string> = {
    LOW: '#6B6B72',
    MEDIUM: '#A8A8AE',
    'MEDIUM-HIGH': '#EAB308',
    HIGH: '#F59E0B',
    'VERY HIGH': '#EF4444'
  }
  return (
    <span className="badge" style={{ background: 'var(--panel-2)', borderColor: 'var(--border)', color: colorMap[impact] || '#A8A8AE' }}>
      {impact}
    </span>
  )
}
