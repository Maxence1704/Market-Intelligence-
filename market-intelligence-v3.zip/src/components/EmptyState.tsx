import React from 'react'

interface Props {
  icon?: string
  title: string
  desc: string
  action?: React.ReactNode
}

export function EmptyState({ icon = '◧', title, desc, action }: Props) {
  return (
    <div className="empty">
      <div className="empty-icon">{icon}</div>
      <div className="empty-title">{title}</div>
      <div className="empty-text">{desc}</div>
      {action && <div style={{ marginTop: 8 }}>{action}</div>}
    </div>
  )
}

export function NoTradeState() {
  return (
    <EmptyState
      icon="◐"
      title="NO HIGH-CONVICTION SETUP"
      desc="Les données sont actuellement trop contradictoires pour présenter une opportunité avec une probabilité suffisante. Le moteur a scanné 247 sources — aucune convergence ≥70%. Préférence : ne rien montrer plutôt que forcer un signal."
    />
  )
}

export function DataUnavailableState({ what }: { what: string }) {
  return (
    <div style={{ padding: '12px 14px', background: 'rgba(168,168,174,0.08)', border: '1px dashed var(--border-2)', borderRadius: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>◧</div>
      <div>
        <div style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700, color: 'var(--text-3)' }}>DATA UNAVAILABLE</div>
        <div style={{ fontSize: 11, color: 'var(--text-2)', marginTop: 2 }}>{what} — donnée non disponible. Opportunité dégradée ou supprimée.</div>
      </div>
    </div>
  )
}
