import React, { useState } from 'react'
import { AppLayout } from './layouts/AppLayout'
import { Overview } from './pages/Overview'
import { Markets } from './pages/Markets'
import { Calendar } from './pages/Calendar'
import { Watchlist } from './pages/Watchlist'
import { History } from './pages/History'
import { Sources } from './pages/Sources'
import { useOpportunities } from './hooks/useOpportunities'
import { useSearch } from './hooks/useSearch'
import { Page, MarketTab } from './types'
import { Collapsible } from './components/Collapsible'
import { ConsensusVisual, ScenarioDistribution } from './components/ConsensusVisual'
import { Badge, VerifiedBadge, DemoBadge } from './components/Badge'
import { ProbabilityRing } from './components/ProbabilityRing'
import { MiniChart } from './components/MiniChart'
import { demoOpportunities } from './data/demo'

export default function App() {
  const [page, setPage] = useState<Page>('overview')
  const [marketTab, setMarketTab] = useState<MarketTab>('indices')
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('wl') || '[]')
    } catch {
      return []
    }
  })

  const { highConviction, extended, extendedMode, toggleExtended, selected, setSelectedId } = useOpportunities()
  const { query, setQuery, results, hasQuery } = useSearch()

  const allOpps = demoOpportunities
  const opportunities = allOpps

  const handleWatch = (id: string) => {
    setWatchlist(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
      localStorage.setItem('wl', JSON.stringify(next))
      return next
    })
  }

  const handleAnalyze = (id: string) => {
    setSelectedId(id)
  }

  const handleAlerts = () => {
    alert(
      `🔔 Alerts — Source Trust System\n\n• BLS CPI demain 14:30 — S 99 OFFICIAL — Age dans 28h\n• BoJ Minutes vérifié MoF S 94 — Trust Gate PASS\n• Conflit IEA vs EIA +18M vs +12M — expliqué\n• NASDAQ LONG 74% → si CPI 2.6% → upgrade 82%\n• Jeudi 16h30 — Fenêtre prise de profit / SHORT potentiel\n• 3 opportunités Trust Gate PASSED`
    )
  }

  const selectedOpp = selected

  return (
    <AppLayout
      current={page}
      onChange={setPage}
      query={query}
      onQueryChange={setQuery}
      extendedMode={extendedMode}
      onToggleExtended={toggleExtended}
      onAlerts={handleAlerts}
      highCount={highConviction.length}
      extendedCount={extended.length}
    >
      {hasQuery ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', fontWeight: 600 }}>Search — "{query}"</div>
            <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>{results.length} résultats — S + A+ + A</div>
          </div>
          <div className="cards-grid">
            {results.map(o => (
              <div key={o.id} style={{ cursor: 'pointer' }} onClick={() => handleAnalyze(o.id)}>
                <div className="opp-card">
                  <div className="opp-asset">{o.market}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-2)' }}>{o.thesisOneLiner}</div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>{o.sources.slice(0, 3).map(s => <Badge key={s.id} variant={s.tier === 'S' ? 'official' : s.tier === 'A+' ? 'trader' : 'market'}>{s.tier} {s.type.split(' ')[0]}</Badge>)}</div>
                </div>
              </div>
            ))}
            {results.length === 0 && (
              <div style={{ gridColumn: '1 / -1' }}>
                <div className="empty">
                  <div className="empty-icon">⌕</div>
                  <div className="empty-title">Aucune source</div>
                  <div className="empty-text">Essayez BLS, Fed, BoJ, Forex Factory, Treasury, NASDAQ, GOLD...</div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <>
          {page === 'overview' && (
            <Overview high={highConviction} extended={extended} extendedMode={extendedMode} onAnalyze={handleAnalyze} onWatch={handleWatch} watchlist={watchlist} />
          )}
          {page === 'markets' && (
            <Markets tab={marketTab} onTabChange={setMarketTab} opportunities={allOpps} onAnalyze={handleAnalyze} onWatch={handleWatch} watchlist={watchlist} />
          )}
          {page === 'calendar' && <Calendar />}
          {page === 'watchlist' && <Watchlist watchlist={watchlist} opportunities={allOpps} onAnalyze={handleAnalyze} onWatch={handleWatch} />}
          {page === 'history' && <History />}
          {page === 'sources' && <Sources />}
        </>
      )}

      {/* Drawer - Deep Dive */}
      <div className={`overlay ${selectedOpp ? 'open' : ''}`} onClick={() => setSelectedId(null)} />
      <div className={`drawer ${selectedOpp ? 'open' : ''}`}>
        {selectedOpp && (
          <>
            <div className="drawer-head">
              <div className="drawer-title">
                DEEP DIVE — {selectedOpp.market} {selectedOpp.direction} {selectedOpp.arrow} — {selectedOpp.probability}% — GATE {selectedOpp.trustGate}
              </div>
              <button className="btn" onClick={() => setSelectedId(null)}>
                ✕ Fermer
              </button>
            </div>
            <div className="drawer-body">
              {/* Header visual */}
              <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: 16, padding: 16, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 20 }}>
                <ProbabilityRing value={selectedOpp.probability} size={80} direction={selectedOpp.direction} label="Probability" />
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em' }}>{selectedOpp.market} <span style={{ color: selectedOpp.direction === 'LONG' ? 'var(--green)' : 'var(--red)' }}>{selectedOpp.direction} {selectedOpp.arrow}</span></div>
                  <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5 }}>{selectedOpp.thesisOneLiner} — {selectedOpp.summary}</div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 4 }}>
                    <Badge variant="verified">✓ {selectedOpp.sources.filter(s => s.verified).length} VERIFIED</Badge>
                    <DemoBadge />
                    <span className="badge" style={{ background: selectedOpp.trustGate === 'PASS' ? 'var(--green-dim)' : 'var(--yellow-dim)', color: selectedOpp.trustGate === 'PASS' ? 'var(--green)' : 'var(--yellow)', borderColor: selectedOpp.trustGate === 'PASS' ? 'var(--green-border)' : 'rgba(234,179,8,0.22)' }}>
                      TRUST GATE {selectedOpp.trustGate}
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                    <MiniChart data={[10, 12, 11, 14, 13, 16, 18, 17, 20, 22]} color={selectedOpp.direction === 'LONG' ? 'var(--green)' : 'var(--red)'} height={40} />
                  </div>
                </div>
              </div>

              {/* Thesis */}
              <Collapsible title="Thesis — 10 questions" icon="◧" defaultOpen={true} badge={<Badge variant="official">OFFICIAL + TRADER</Badge>}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 11, lineHeight: 1.6 }}>
                  <div>
                    <strong>QUOI ?</strong> {selectedOpp.market} {selectedOpp.direction}<br />
                    <strong>QUAND ?</strong> {selectedOpp.catalyst.date} {selectedOpp.catalyst.time}<br />
                    <strong>ACTIF ?</strong> {selectedOpp.ticker}<br />
                    <strong>DIRECTION ?</strong> {selectedOpp.direction}<br />
                    <strong>PROBA ?</strong> {selectedOpp.probability}%<br />
                  </div>
                  <div>
                    <strong>FIABILITÉ ?</strong> {selectedOpp.reliability}/100<br />
                    <strong>IMPACT ?</strong> {selectedOpp.impact} ({selectedOpp.timeHorizon})<br />
                    <strong>CATALYSEUR ?</strong> {selectedOpp.catalyst.event}<br />
                    <strong>INVALIDATION ?</strong> {selectedOpp.invalidation[0]}<br />
                    <strong>MOVE ?</strong> {selectedOpp.expectedMove}
                  </div>
                </div>
              </Collapsible>

              {/* Chain */}
              <Collapsible title="Chaîne causale — Cœur du système" icon="◨" defaultOpen={true}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                  {selectedOpp.chain.map((step, i) => (
                    <React.Fragment key={step.id}>
                      <div style={{ display: 'flex', gap: 12, padding: '10px 0', borderBottom: i < selectedOpp.chain.length - 1 ? '1px dashed var(--border)' : 'none' }}>
                        <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, flexShrink: 0 }}>{step.icon}</div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 11, fontWeight: 600, display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                            {step.title} {step.sourceBadge && <Badge variant="official">{step.sourceBadge}</Badge>}
                          </div>
                          <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 2 }}>{step.desc}</div>
                        </div>
                      </div>
                      {i < selectedOpp.chain.length - 1 && <div style={{ marginLeft: 13, color: 'var(--text-3)', fontSize: 10 }}>↓</div>}
                    </React.Fragment>
                  ))}
                </div>
              </Collapsible>

              {/* Consensus visual */}
              <Collapsible title="Consensus vs Modèle — Visual" icon="◫" defaultOpen={true}>
                <ConsensusVisual consensus={selectedOpp.consensus} />
              </Collapsible>

              {/* Scenarios */}
              <Collapsible title="Scénarios probabilisés" icon="◷" defaultOpen={true}>
                <ScenarioDistribution scenarios={selectedOpp.scenarios} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
                  {selectedOpp.scenarios.map((s, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, padding: 10, border: '1px solid var(--border)', borderRadius: 10, background: s.prob >= 70 ? 'var(--panel-2)' : 'var(--panel)' }}>
                      <div style={{ fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 700, minWidth: 36 }}>{s.prob}%</div>
                      <div style={{ fontSize: 11, lineHeight: 1.4, color: 'var(--text-2)' }}>
                        <strong style={{ color: 'var(--text)' }}>{s.label}</strong> — {s.desc} {s.expectedMove && <span style={{ color: 'var(--green)', fontFamily: 'var(--mono)' }}>→ {s.expectedMove}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </Collapsible>

              {/* Why */}
              <Collapsible title="Why this trade? — 3 key reasons" icon="◐">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {selectedOpp.whyDetailed.map((w, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, padding: '10px 12px', background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 12 }}>
                      <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text-3)', minWidth: 20 }}>0{i + 1}</div>
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 600 }}>{w.title}</div>
                        <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.4 }}>{w.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </Collapsible>

              {/* Bull vs Bear */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div style={{ padding: 12, borderRadius: 12, border: '1px solid rgba(34,197,94,0.18)', background: 'rgba(34,197,94,0.06)' }}>
                  <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--green)', fontWeight: 700, marginBottom: 8 }}>Bull Case</div>
                  <ul style={{ marginLeft: 12 }}>
                    {selectedOpp.bull.map((b, i) => (
                      <li key={i} style={{ fontSize: 10, lineHeight: 1.4, color: 'var(--text-2)', marginBottom: 4 }}>
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
                <div style={{ padding: 12, borderRadius: 12, border: '1px solid rgba(239,68,68,0.18)', background: 'rgba(239,68,68,0.06)' }}>
                  <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--red)', fontWeight: 700, marginBottom: 8 }}>Bear Case</div>
                  <ul style={{ marginLeft: 12 }}>
                    {selectedOpp.bear.map((b, i) => (
                      <li key={i} style={{ fontSize: 10, lineHeight: 1.4, color: 'var(--text-2)', marginBottom: 4 }}>
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Evidence */}
              <Collapsible title="Evidence — Traçabilité totale" icon="📄" badge={<VerifiedBadge count={selectedOpp.evidence.length} />}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {selectedOpp.evidence.map(ev => (
                    <div key={ev.id} style={{ padding: '10px 12px', border: '1px solid var(--border)', borderRadius: 12, background: 'var(--panel)', display: 'flex', gap: 10 }}>
                      <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, flexShrink: 0 }}>📄</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                          {ev.point} <Badge variant={ev.badge === 'OFFICIAL SOURCE' ? 'official' : ev.badge === 'TRADER SOURCE' ? 'trader' : 'market'}>{ev.badge}</Badge>
                        </div>
                        <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 4, lineHeight: 1.4 }}>
                          Source: {ev.sourceName} — Tier {ev.tier} — {ev.reliability}/100 — {ev.verified}
                        </div>
                        <div style={{ fontFamily: 'var(--mono)', fontSize: 8, color: 'var(--text-3)', marginTop: 6, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                          <span>Age: {ev.age}</span>
                          <span>WHO: {ev.who}</span>
                          <span>WHERE: {ev.where}</span>
                          <span>Primary: {ev.isPrimary ? 'Yes' : 'No'}</span>
                          <span>Confirmed: {ev.isConfirmed ? 'Yes' : 'No'}</span>
                        </div>
                        <div style={{ fontSize: 9, color: 'var(--text-3)', marginTop: 4 }}>Transformation: {ev.transformation}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </Collapsible>

              {/* Sources */}
              <Collapsible title="Sources — Transparence totale" icon="🛡" badge={<span style={{ fontFamily: 'var(--mono)', fontSize: 9, color: 'var(--text-3)' }}>{selectedOpp.sources.length} sources</span>}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                  {selectedOpp.sources.map(s => (
                    <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderBottom: '1px solid var(--border)', gap: 10, flexWrap: 'wrap' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                        <span style={{ fontWeight: 600, fontSize: 11 }}>{s.name}</span>
                        <Badge variant={s.tier === 'S' ? 'official' : s.tier === 'A+' ? 'trader' : 'market'}>
                          {s.tier} • {s.type} • {s.reliability}/100
                        </Badge>
                        <span style={{ fontSize: 9, color: 'var(--text-3)' }}>{s.role}</span>
                      </div>
                      <div style={{ fontFamily: 'var(--mono)', fontSize: 9, color: 'var(--text-3)', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                        <span>{s.date} • Age {s.age}</span>
                        <span>{s.verified ? '✓ Vérifié' : '✕ Non vérifié'}</span>
                        <span>Cross-check {s.crossChecked}</span>
                        <a href={`https://${s.url}`} target="_blank" rel="noreferrer" style={{ color: '#93C5FD', textDecoration: 'none' }}>
                          {s.url}
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </Collapsible>

              {/* Invalidation */}
              <div style={{ padding: '12px 14px', background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)', borderRadius: 12 }}>
                <div style={{ fontSize: 9, letterSpacing: '0.12em', color: 'var(--red)', textTransform: 'uppercase', fontWeight: 700, marginBottom: 6 }}>Invalidation — Ce qui tuerait la thèse</div>
                <div style={{ fontSize: 11, color: '#FFA0A0', lineHeight: 1.5 }}>{selectedOpp.invalidation.join(' • ')}</div>
              </div>

              {/* What would change view */}
              <div style={{ padding: 12, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 12 }}>
                <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', fontWeight: 600, marginBottom: 8 }}>What would change the view?</div>
                <ul style={{ marginLeft: 14 }}>
                  {selectedOpp.whatChanges.map((w, i) => (
                    <li key={i} style={{ fontSize: 11, lineHeight: 1.5, color: 'var(--text-2)', marginBottom: 4 }}>
                      {w}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </>
        )}
      </div>
    </AppLayout>
  )
}
