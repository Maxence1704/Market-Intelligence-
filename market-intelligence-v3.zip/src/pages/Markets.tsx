import React, { useState } from 'react'
import { MarketTab, Opportunity } from '../types'
import { OpportunityCard } from '../components/OpportunityCard'
import { EmptyState } from '../components/EmptyState'

interface Props {
  tab: MarketTab
  onTabChange: (t: MarketTab) => void
  opportunities: Opportunity[]
  onAnalyze: (id: string) => void
  onWatch: (id: string) => void
  watchlist: string[]
}

const tabs: { id: MarketTab; label: string }[] = [
  { id: 'forex', label: 'Forex' },
  { id: 'indices', label: 'Indices' },
  { id: 'stocks', label: 'Stocks' },
  { id: 'crypto', label: 'Crypto' },
  { id: 'commodities', label: 'Commodities' },
  { id: 'bonds', label: 'Bonds & Rates' },
  { id: 'macro', label: 'Macro' }
]

const assetsByTab: Record<MarketTab, string[]> = {
  forex: ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'NZD/USD', 'USD/CAD'],
  indices: ['NASDAQ 100', 'S&P 500', 'Dow Jones', 'Russell 2000', 'VIX', 'CAC 40', 'DAX'],
  stocks: ['AAPL', 'NVDA', 'MSFT', 'TSLA', 'ASML', 'LVMH'],
  crypto: ['BTC', 'ETH', 'SOL', 'AVAX'],
  commodities: ['Gold', 'Silver', 'Brent', 'WTI', 'Copper'],
  bonds: ['US 2Y', 'US 10Y', 'US 30Y', 'Bund', 'OAT', 'Gilts'],
  macro: ['US', 'EU', 'UK', 'JP', 'CN']
}

export function Markets({ tab, onTabChange, opportunities, onAnalyze, onWatch, watchlist }: Props) {
  const [search] = useState('')
  const assets = assetsByTab[tab] || []

  const filteredOpps = opportunities.filter(o => {
    if (tab === 'indices' && o.market.includes('NASDAQ')) return true
    if (tab === 'commodities' && (o.market.includes('GOLD') || o.market.includes('BRENT'))) return true
    if (tab === 'forex' && o.market.includes('USD')) return true
    if (tab === 'bonds' && o.market.includes('NASDAQ')) return false // show none for demo except relevant
    return assets.some(a => o.market.toUpperCase().includes(a.split(' ')[0]) || a.toUpperCase().includes(o.market.split('/')[0]))
  })

  // For demo, show relevant opps per tab
  const relevant = tab === 'indices' ? opportunities.filter(o => o.id === '01') :
    tab === 'commodities' ? opportunities.filter(o => o.id === '02' || o.id === '04') :
    tab === 'forex' ? opportunities.filter(o => o.id === '03') :
    tab === 'macro' ? [] : filteredOpps

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div className="page-title">Markets • {tab.toUpperCase()}</div>
        <div className="page-subtitle">{tabs.find(t => t.id === tab)?.label} — Macro drivers, not price only</div>
        <div className="page-desc">Chaque marché analysé via sources S + A+. Pas de prix isolé, mais chaîne causale + cross-asset.</div>
      </div>

      <div style={{ display: 'flex', gap: 8, overflow: 'auto', paddingBottom: 4 }}>
        {tabs.map(t => (
          <button key={t.id} className={`pill ${tab === t.id ? 'active' : ''}`} onClick={() => onTabChange(t.id)} style={{ cursor: 'pointer', whiteSpace: 'nowrap' }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {assets.map(a => (
          <span key={a} className="badge" style={{ background: 'var(--panel)', borderColor: 'var(--border)', color: 'var(--text-3)', padding: '6px 10px', fontSize: 10 }}>
            {a}
          </span>
        ))}
      </div>

      {relevant.length === 0 ? (
        <EmptyState
          icon="◫"
          title={`NO HIGH-CONVICTION SETUP — ${tab.toUpperCase()}`}
          desc={`Aucune opportunité ≥70% sur ${tab} cette semaine avec Trust Gate PASS. Le moteur a scanné ${tab} — pas de convergence suffisante. C'est normal. On préfère 0 opportunité moyenne à 5 forcées.`}
        />
      ) : (
        <div className="cards-grid">
          {relevant.map(o => (
            <OpportunityCard key={o.id} opp={o} onAnalyze={onAnalyze} onWatch={onWatch} isWatched={watchlist.includes(o.id)} />
          ))}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16 }}>
          <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', marginBottom: 8, fontWeight: 600 }}>Ce que le moteur vérifie</div>
          <div style={{ fontSize: 11, lineHeight: 1.6, color: 'var(--text-2)' }}>
            • Sources primaires S (Fed, BLS, BoJ)<br />• Révisions vs première publication<br />• Consensus Forex Factory A+ vs primaire<br />• Cross-asset confirmation<br />• Positionnement COT / ETF flows<br />• Bull vs Bear — cherche contre-thèse
          </div>
        </div>
        <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16 }}>
          <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', marginBottom: 8, fontWeight: 600 }}>Règle de discipline</div>
          <div style={{ fontSize: 11, lineHeight: 1.6, color: 'var(--text-2)' }}>
            Le système ne doit jamais inventer de données. Il doit pouvoir dire <strong style={{ color: 'var(--text)' }}>I DON'T KNOW / NO TRADE</strong> lorsque données insuffisantes.
          </div>
        </div>
      </div>
    </div>
  )
}
