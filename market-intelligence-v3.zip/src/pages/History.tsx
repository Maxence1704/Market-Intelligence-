import React from 'react'
import { historyEntries } from '../data/demo'

export function History() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div className="page-title">History & Calibration</div>
        <div className="page-subtitle">Probabilités = estimations, jamais certitudes — calibration mesurée</div>
        <div className="page-desc">Chaque opportunité enregistrée : date, actif, direction, proba, sources S + A+, résultat, calibration. Permet de mesurer si probas bien calibrées.</div>
      </div>

      <div className="kpi-row">
        <div className="kpi"><div className="kpi-label">70-75% — 127 obs</div><div className="kpi-value">68.5% win</div><div className="kpi-sub"><strong>Calibration OK</strong> — proche cible 70-75%</div></div>
        <div className="kpi"><div className="kpi-label">75-80% — 84 obs</div><div className="kpi-value">73.8% win</div><div className="kpi-sub"><strong>Légèrement sous-calibré</strong> — ajustement en cours</div></div>
        <div className="kpi"><div className="kpi-label">&gt;80% — 31 obs</div><div className="kpi-value">77.4% win</div><div className="kpi-sub"><strong>Très sélectif</strong> — 85% doit être rare</div></div>
        <div className="kpi"><div className="kpi-label">Trust Gate</div><div className="kpi-value" style={{ color: 'var(--green)' }}>98.2% PASS</div><div className="kpi-sub">1.8% FAIL → NO TRADE auto</div></div>
      </div>

      <div style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
        <div style={{ overflow: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Date</th>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Actif</th>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Dir</th>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Proba</th>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Sources</th>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Gate</th>
                <th style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>Résultat</th>
              </tr>
            </thead>
            <tbody>
              {historyEntries.map((h, i) => (
                <tr key={i} style={{ transition: 'background .15s' }}>
                  <td style={{ fontSize: 11, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: 'var(--text-2)', fontFamily: 'var(--mono)' }}>{h.date}</td>
                  <td style={{ fontSize: 11, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: 'var(--text-2)', fontFamily: 'var(--mono)' }}>{h.asset}</td>
                  <td style={{ fontSize: 11, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: h.dir === 'LONG' ? 'var(--green)' : 'var(--red)', fontFamily: 'var(--mono)', fontWeight: 600 }}>{h.dir}</td>
                  <td style={{ fontSize: 11, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: 'var(--text-2)', fontFamily: 'var(--mono)' }}>{h.prob}</td>
                  <td style={{ fontSize: 10, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>{h.sources}</td>
                  <td style={{ fontSize: 10, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: h.gate === 'PASS' ? 'var(--green)' : 'var(--red)', fontFamily: 'var(--mono)' }}>{h.gate}</td>
                  <td style={{ fontSize: 11, padding: '10px 12px', borderBottom: '1px solid var(--border)', color: 'var(--text-2)', fontFamily: 'var(--mono)' }}>{h.result}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16 }}>
        <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', marginBottom: 8, fontWeight: 600 }}>Note de calibration</div>
        <div style={{ fontSize: 11, lineHeight: 1.6, color: 'var(--text-2)' }}>
          Le moteur enregistre chaque opportunité avec date, heure, actif, direction, proba, confidence, données utilisées, scénario, résultat, performance. Si 70-75% prédictions réussissent 68.5% du temps, c'est proche et acceptable. Si elles réussissaient 45%, le moteur serait sur-confiant et devrait être pénalisé. 85% doit être extrêmement rare — seulement 31 obs &gt;80% historiquement.
        </div>
      </div>
    </div>
  )
}
