import React from 'react'
import { OpportunityCard } from '../components/OpportunityCard'
import { NoTradeState } from '../components/EmptyState'
import { Badge } from '../components/Badge'
import { Opportunity } from '../types'

interface Props {
  high: Opportunity[]
  extended: Opportunity[]
  extendedMode: boolean
  onAnalyze: (id: string) => void
  onWatch: (id: string) => void
  watchlist: string[]
}

export function Overview({ high, extended, extendedMode, onAnalyze, onWatch, watchlist }: Props) {
  const all = extendedMode ? [...high, ...extended] : high

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Today header */}
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div className="page-title">Today • {new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })} • Updated 2 min ago</div>
        <div className="page-subtitle">
          {high.length === 0 ? 'No high-conviction setup today' : `${high.length} high-conviction opportunit${high.length > 1 ? 'ies' : 'y'}`}
        </div>
        <div className="page-desc">
          Intelligence filtrée en arrière-plan. 247 sources scannées → 96.4% filtrées → {high.length} opportunités ≥70%. Philosophie : 2 excellentes {' > '} 20 moyennes.
        </div>
      </div>

      {/* KPIs minimal */}
      <div className="kpi-row">
        <div className="kpi">
          <div className="kpi-label">Sources S Tier</div>
          <div className="kpi-value">68% <span style={{ fontSize: 11, color: 'var(--text-3)' }}>primaires</span></div>
          <div className="kpi-sub">Fed, BLS, BoJ, Treasury — vérifiées</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Trust Gate</div>
          <div className="kpi-value" style={{ color: 'var(--green)' }}>{high.length} PASSED</div>
          <div className="kpi-sub">Aucune source critique non vérifiée</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Filtering</div>
          <div className="kpi-value">96.4% <span style={{ fontSize: 11, color: 'var(--text-3)' }}>filtered</span></div>
          <div className="kpi-sub">183 signaux rejetés</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Regime</div>
          <div className="kpi-value" style={{ fontSize: 13 }}>USD SOFT + YIELDS ↓</div>
          <div className="kpi-sub">Favorable Growth / Gold / Crypto</div>
        </div>
      </div>

      {/* Divergence banner - minimal */}
      <div style={{ padding: '12px 14px', background: 'rgba(234,179,8,0.07)', border: '1px solid rgba(234,179,8,0.18)', borderRadius: 16, display: 'flex', gap: 12, alignItems: 'flex-start' }}>
        <div style={{ width: 28, height: 28, borderRadius: 9, background: 'rgba(234,179,8,0.15)', border: '1px solid rgba(234,179,8,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 12 }}>⚠️</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700, color: '#EAB308', marginBottom: 4 }}>Contradiction externe tracée — Jeudi 16h30</div>
          <div style={{ fontSize: 11, lineHeight: 1.5, color: 'var(--text-2)' }}>
            Autre système : <strong style={{ color: 'var(--text)' }}>SHORT Nasdaq jeudi 16h30</strong> vs Nous : <strong style={{ color: 'var(--text)' }}>LONG mardi 14:30 CPI</strong> → Séquentiel possible : LONG mardi → SHORT jeudi (fade). Timeline dans Calendar.
          </div>
          
        </div>
      </div>

      {/* Top opportunities */}
      <div>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 600 }}>Top Opportunities</div>
          <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>Max 10/week • Plafond, pas objectif • {all.length} visibles</div>
        </div>

        {all.length === 0 ? (
          <NoTradeState />
        ) : (
          <div className="cards-grid">
            {all.map(opp => (
              <OpportunityCard key={opp.id} opp={opp} onAnalyze={onAnalyze} onWatch={onWatch} isWatched={watchlist.includes(opp.id)} />
            ))}
          </div>
        )}
      </div>

      {/* Source trust minimal */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', padding: '10px 12px', background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 12 }}>
        <Badge variant="verified">✓ 8 SOURCES VERIFIED</Badge>
        <Badge variant="official">S TIER 99 OFFICIAL</Badge>
        <Badge variant="trader">A+ 95 TRADER</Badge>
        <span style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>Forex Factory pour consensus/horaires — toujours cross-check vs BLS primaire</span>
      </div>
    </div>
  )
}
