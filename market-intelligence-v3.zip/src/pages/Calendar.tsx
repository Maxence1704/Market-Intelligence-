import React from 'react'
import { calendarEvents } from '../data/demo'
import { Badge } from '../components/Badge'

export function Calendar() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div className="page-title">Intelligent Calendar • Source Verified</div>
        <div className="page-subtitle">Pas un calendrier classique — Pourquoi, impact, scénarios</div>
        <div className="page-desc">Chaque événement = pourquoi ça compte, actifs concernés, consensus vs modèle, surprise potentielle, sources S + A+.</div>
      </div>

      <div className="kpi-row">
        <div className="kpi"><div className="kpi-label">Cette semaine</div><div className="kpi-value">3 VERY HIGH</div><div className="kpi-sub">CPI BLS S 99, China NBS S 90, BoJ S 97</div></div>
        <div className="kpi"><div className="kpi-label">Surprise potentielle</div><div className="kpi-value" style={{ color: '#EAB308' }}>-0.2pp CPI</div><div className="kpi-sub">Modèle 2.6% vs Consensus 2.8%</div></div>
        <div className="kpi"><div className="kpi-label">Jeudi 16h30</div><div className="kpi-value" style={{ fontSize: 12 }}>LONG → SHORT</div><div className="kpi-sub">Mardi LONG CPI, jeudi SHORT fade</div></div>
        <div className="kpi"><div className="kpi-label">Trader Source</div><div className="kpi-value" style={{ fontSize: 12 }}>Forex Factory A+ 95</div><div className="kpi-sub">Horaires + consensus + importance — cross-check vs primaire</div></div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {calendarEvents.map(ev => (
          <div key={ev.id} className="fade-in" style={{ display: 'flex', gap: 14, padding: '14px 16px', background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16, transition: 'all .2s' }}>
            <div style={{ width: 80, flexShrink: 0 }}>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 14, fontWeight: 600 }}>{ev.date}</div>
              <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--mono)', marginTop: 2 }}>{ev.time}</div>
              <div style={{ marginTop: 6 }}><span className="badge" style={{ background: ev.importance === 'VERY HIGH' ? 'rgba(239,68,68,0.12)' : ev.importance === 'HIGH' ? 'rgba(234,179,8,0.12)' : 'var(--panel-2)', color: ev.importance === 'VERY HIGH' ? 'var(--red)' : ev.importance === 'HIGH' ? 'var(--yellow)' : 'var(--text-3)', borderColor: ev.importance === 'VERY HIGH' ? 'rgba(239,68,68,0.22)' : ev.importance === 'HIGH' ? 'rgba(234,179,8,0.22)' : 'var(--border)', fontSize: 7 }}>{ev.importance}</span></div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                {ev.title}
                {ev.sources.map((s, i) => (
                  <Badge key={i} variant={s.includes('S 99') || s.includes('S 97') || s.includes('S 94') ? 'official' : s.includes('A+') ? 'trader' : 'market'}>
                    {s.split(' ')[0]} {s.includes('S') ? 'OFFICIAL' : s.includes('A+') ? 'TRADER' : 'MARKET'}
                  </Badge>
                ))}
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5, marginTop: 6 }}>
                <strong style={{ color: 'var(--text)' }}>Pourquoi cela compte :</strong> {ev.desc}
                {ev.surprise && <><br /><span style={{ color: '#EAB308', fontFamily: 'var(--mono)', fontSize: 10 }}>→ {ev.surprise}</span></>}
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 10 }}>
                {ev.assets.map(a => (
                  <span key={a} style={{ fontSize: 8, letterSpacing: '0.06em', padding: '3px 7px', borderRadius: 999, background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>{a}</span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
