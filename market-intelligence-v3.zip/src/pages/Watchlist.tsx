import React from 'react'
import { Opportunity } from '../types'
import { OpportunityCard } from '../components/OpportunityCard'
import { EmptyState } from '../components/EmptyState'

interface Props {
  watchlist: string[]
  opportunities: Opportunity[]
  onAnalyze: (id: string) => void
  onWatch: (id: string) => void
}

export function Watchlist({ watchlist, opportunities, onAnalyze, onWatch }: Props) {
  const items = watchlist.map(id => opportunities.find(o => o.id === id)).filter(Boolean) as Opportunity[]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div className="page-title">Watchlist • {items.length} assets</div>
        <div className="page-subtitle">Opportunités suivies — alertes si proba &gt;70% ou Trust Gate FAIL</div>
        <div className="page-desc">Ajoutées via + sur les cartes. Alertes si probabilité passe au-dessus de 70% ou chute fortement, thèse invalidée.</div>
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon="☆"
          title="Watchlist vide"
          desc="Ajoutez des opportunités via le bouton + sur les cartes. Vous recevrez des alertes si proba passe >70% ou <65%, ou si thèse invalidée."
        />
      ) : (
        <div className="cards-grid">
          {items.map(o => (
            <OpportunityCard key={o.id} opp={o} onAnalyze={onAnalyze} onWatch={onWatch} isWatched={true} />
          ))}
        </div>
      )}
    </div>
  )
}
