import React from 'react'
import { Badge } from '../components/Badge'

export function Sources() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div className="page-title">Source Hierarchy — S → A+ → A → Trust Gate</div>
        <div className="page-subtitle">Moins de données mais meilleures données {' > '} beaucoup de données qualité inconnue</div>
        <div className="page-desc">Chaque information importante vérifiée. Cliquer sur n'importe quelle affirmation → retrouver QUI, QUAND, OÙ, primaire ?, confirmé ?, donnée originale ?, transformation ?</div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ padding: '14px 16px', borderRadius: 16, border: '1px solid rgba(96,165,250,0.22)', background: 'rgba(96,165,250,0.08)', display: 'flex', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 13, color: '#93C5FD', flexShrink: 0 }}>S</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700 }}>NIVEAU S — SOURCES PRIMAIRES / OFFICIELLES — 95-99/100</div>
            <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5, marginTop: 4 }}><strong>Priorité absolue.</strong> Federal Reserve, FOMC, BLS, BEA, Census, Treasury, SEC, ECB, Eurostat, BoE, ONS, BoJ, MoF, PBoC, NBS China, CFTC, EIA. Exemple : BLS CPI Release = S 99 OFFICIAL SOURCE — vérifié via bls.gov, date/heure/timezone, valeur/unité/previous/consensus/révision, cross-check FRED.</div>
            <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}><Badge variant="official">OFFICIAL SOURCE</Badge><span style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>Utilisé pour données éco, taux officiels, minutes, COT</span></div>
          </div>
        </div>

        <div style={{ padding: '14px 16px', borderRadius: 16, border: '1px solid rgba(234,179,8,0.22)', background: 'rgba(234,179,8,0.08)', display: 'flex', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 12, color: '#FDE68A', flexShrink: 0 }}>A+</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700 }}>NIVEAU A+ — SOURCES TRADER HAUTE QUALITÉ — 88-95/100</div>
            <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5, marginTop: 4 }}><strong>Forex Factory</strong> = référence trader pro pour calendrier, horaires, importance, consensus, previous, actual, volatilité. <strong>IMPORTANT :</strong> Jamais considéré comme source primaire du chiffre. Si chiffre original disponible chez BLS/Fed/ECB, récupérer et vérifier auprès du primaire. FF pour consensus 2.8% mais vérifié vs Bloomberg + Reuters poll.</div>
            <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}><Badge variant="trader">TRADER SOURCE</Badge><span style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>Horaires, consensus, importance — toujours cross-check vs S</span></div>
          </div>
        </div>

        <div style={{ padding: '14px 16px', borderRadius: 16, border: '1px solid var(--border)', background: 'var(--panel)', display: 'flex', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>A</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700 }}>NIVEAU A — MARKET DATA RECONNU — 80-94/100</div>
            <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5, marginTop: 4 }}>CME FedWatch, Treasury market data, CFTC, ICE, Bloomberg. Pour Forex = OTC, prix peut varier selon fournisseur → comparer plusieurs flux. Utilisé pour futures, yields, ETF flows, funding.</div>
            <div style={{ marginTop: 8 }}><Badge variant="market">MARKET DATA</Badge></div>
          </div>
        </div>

        <div style={{ padding: '14px 16px', borderRadius: 16, border: '1px dashed rgba(239,68,68,0.22)', background: 'rgba(239,68,68,0.06)', display: 'flex', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--panel-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: 'var(--red)', flexShrink: 0 }}>✕</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700 }}>INTERDIT — AUCUNE SOURCE ANONYME COMME PRINCIPALE</div>
            <div style={{ fontSize: 11, color: 'var(--text-2)', lineHeight: 1.5, marginTop: 4 }}>X/Twitter anonyme, Telegram anonyme, Reddit, forums, blogs inconnus, sites sans méthodo, screenshots, origine non vérifiable. Peuvent servir à détecter sentiment, mais jamais seules pour construire opportunité &gt;70%.</div>
            <div style={{ marginTop: 8 }}><Badge variant="conflict">SOURCE NOT SUFFICIENTLY RELIABLE → NO TRADE</Badge></div>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16 }}>
          <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', fontWeight: 600, marginBottom: 8 }}>Source Score — Critères objectifs</div>
          <div style={{ fontSize: 11, lineHeight: 1.6, color: 'var(--text-2)' }}>
            <strong>Fed S 99</strong> — Tier S, primaire, méthodo publique, 0 révision non expliquée<br />
            <strong>BLS S 99</strong> — Tier S, primaire, date/heure/timezone précis<br />
            <strong>Forex Factory A+ 95</strong> — Trader pro, fiable calendrier/consensus, mais secondaire pour chiffre<br />
            <strong>Treasury S 98</strong> — Market data officiel, live, cross-check FRED<br />
            <strong>Zillow A 84</strong> — Secondaire fiable, confirmation uniquement
          </div>
        </div>
        <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16 }}>
          <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', fontWeight: 600, marginBottom: 8 }}>Source Confidence ≠ Trade Probability</div>
          <div style={{ fontSize: 11, lineHeight: 1.6, color: 'var(--text-2)' }}>
            <strong>Source reliability 99/100</strong> = "Donnée fiable ?" Oui.<br />
            <strong>Trade probability 74%</strong> = "Marché va monter ?" Incertain.<br /><br />
            Donnée parfaite (99/100) mais marché imprévisible. <strong style={{ color: 'var(--text)' }}>Source fiable ≠ trade certain.</strong><br /><br />
            <span style={{ fontFamily: 'var(--mono)', fontSize: 9, color: '#93C5FD' }}>2 scores séparés : Reliability (source) et Probability (trade)</span>
          </div>
        </div>
      </div>

      <div style={{ padding: 14, background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 16 }}>
        <div style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-3)', fontWeight: 600, marginBottom: 10 }}>Pipeline institutionnel — Philosophie finale</div>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 10, lineHeight: 1.8, color: 'var(--text-2)' }}>
          INTERNET / DATA<br />↓ SOURCES AUTORISÉES (S, A+, A)<br />↓ VÉRIFICATION (6 étapes)<br />↓ DONNÉES PRIMAIRES<br />↓ CROSS-CHECK indépendant<br />↓ MACRO ANALYSIS<br />↓ FUNDAMENTAL ANALYSIS<br />↓ CROSS-ASSET CONFIRMATION<br />↓ SCENARIOS<br />↓ PROBABILITY<br />↓ SOURCE TRUST GATE<br />↓ OPPORTUNITY FILTER<br />↓ MAX 10/WEEK<br />↓ HIGH-CONVICTION
        </div>
      </div>
    </div>
  )
}
