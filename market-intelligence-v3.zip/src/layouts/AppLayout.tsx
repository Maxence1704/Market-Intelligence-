import React from 'react'
import { Header } from '../components/Header'
import { Sidebar, BottomNav } from '../components/Sidebar'
import { Page } from '../types'

interface Props {
  current: Page
  onChange: (p: Page) => void
  query: string
  onQueryChange: (q: string) => void
  extendedMode: boolean
  onToggleExtended: () => void
  onAlerts: () => void
  highCount: number
  extendedCount: number
  children: React.ReactNode
}

export function AppLayout({ current, onChange, query, onQueryChange, extendedMode, onToggleExtended, onAlerts, highCount, extendedCount, children }: Props) {
  return (
    <div className="app-root">
      <Header query={query} onQueryChange={onQueryChange} onAlerts={onAlerts} extendedMode={extendedMode} onToggleExtended={onToggleExtended} />
      <div className="layout">
        <Sidebar current={current} onChange={onChange} highCount={highCount} extendedCount={extendedCount} />
        <main className="main">{children}</main>
      </div>
      <BottomNav current={current} onChange={onChange} />
    </div>
  )
}
